using Microsoft.AspNetCore.Identity.EntityFrameworkCore;

namespace FisherAirlines.Data
{
    public class ApplicationUser : IdentityUser
    {
        
    }
}