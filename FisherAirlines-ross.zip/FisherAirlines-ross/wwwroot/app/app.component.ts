import {Component, OnInit} from '@angular/core';
import {APP_BASE_HREF} from 'angular2/common';

@Component({
 selector: 'fisher-airlines',
 templateUrl: './app/app.component.html'

})

export class AppComponent {}

