import {Component} from "@angular/core";
import { AuthService } from '../../auth.service';
@Component({
 selector: 'home-page',
 templateUrl: './app/components/home/home.component.html'
})

export class HomeComponent { 
} 