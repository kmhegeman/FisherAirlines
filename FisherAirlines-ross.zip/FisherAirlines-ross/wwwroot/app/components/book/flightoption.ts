export class Flight {
  constructor(public name: string) { }
}