import {Component} from "@angular/core";
import { AuthService } from '../../auth.service';
@Component({
 selector: 'my-tickets',
 templateUrl: './app/components/mytickets/mytickets.component.html'
})

export class MyticketsComponent { 
} 