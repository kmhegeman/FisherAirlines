import { Component } from '@angular/core';
import { AuthService } from '../../auth.service';
@Component({
 selector: 'flight-status',
 templateUrl: './app/components/status/status.component.html'
})
export class StatusComponent {
} 